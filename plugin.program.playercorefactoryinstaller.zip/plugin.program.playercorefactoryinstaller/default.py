
import xbmc
import xbmcgui
import shutil
import os

# Define source and destination
src = xbmc.translatePath("special://home/addons/plugin.program.playercorefactoryinstaller/resources/playercorefactory.xml")
dst = xbmc.translatePath("special://home/userdata/playercorefactory.xml")

try:
    shutil.copyfile(src, dst)
    xbmcgui.Dialog().ok("PlayerCoreFactory", "تم نسخ الملف بنجاح إلى userdata")
except Exception as e:
    xbmcgui.Dialog().ok("PlayerCoreFactory", f"حدث خطأ: {str(e)}")
